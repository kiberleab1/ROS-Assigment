#include <functional>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>
#include <iostream>
#include <thread>
#include "ros/ros.h"
#include "ros/callback_queue.h"
#include "ros/subscribe_options.h"
#include "std_msgs/Float32.h"
#include "arm_gazebo/JointValues.h"
namespace gazebo
{
	class ModelPush : public ModelPlugin
	{
	public:
		void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
		{
			// Store the pointer to the model
			this->model = _parent;

			// // intiantiate the joint controller
			this->jointController = this->model->GetJointController();

			// // set your PID values
			this->pid = common::PID(90.0, 00.00, 00.03);

			auto joint_name = "arm1_arm2_joint";
			auto joint_name2 = "arm2_arm3_joint";

			auto joint_name3 = "arm3_arm4_joint";
			auto joint_name0 = "chasis_arm1_joint";

			std::string name = this->model->GetJoint("arm1_arm2_joint")->GetScopedName();
			std::string name1 = this->model->GetJoint("arm2_arm3_joint")->GetScopedName();
			std::string name2 = this->model->GetJoint("arm3_arm4_joint")->GetScopedName();
			std::string name0 = this->model->GetJoint("chasis_arm1_joint")->GetScopedName();

			this->jointController->SetPositionPID(name, pid);
			this->jointController->SetPositionPID(name1, pid);

			this->jointController->SetPositionPID(name2, pid);
			this->jointController->SetPositionPID(name0, pid);
			// Listen to the update event. This event is broadcast every
			// simulation iteration.

			if (!ros::isInitialized())
			{
				int argc = 0;
				char **argv = NULL;
				ros::init(argc, argv, "gazebo_client",
						  ros::init_options::NoSigintHandler);
			}

			// Create our ROS node. This acts in a similar manner to
			// the Gazebo node
			this->rosNode.reset(new ros::NodeHandle("gazebo_client"));
			this->rosPub = this->rosNode->advertise<std_msgs::Float32>("/in_value", 10, true);
			this->timer = this->rosNode->createTimer(ros::Duration(1.0 / 50.), &ModelPush::timerCallback,
																this);

			// Create a named topic, and subscribe to it.
		
			ros::SubscribeOptions so =
				ros::SubscribeOptions::create<std_msgs::Float32>(
					"/in_value",
					1,
					boost::bind(&ModelPush::OnRosMsg, this, _1),
					ros::VoidPtr(), &this->rosQueue);
			this->rosSub = this->rosNode->subscribe(so);

			// Spin up the queue helper thread.
			this->rosQueueThread =
				std::thread(std::bind(&ModelPush::QueueThread, this));

			this->updateConnection = event::Events::ConnectWorldUpdateBegin(
				std::bind(&ModelPush::OnUpdate, this));
		}

	public:
		void timerCallback(const ros::TimerEvent &event)
		{
			//this->rosPub.publish("asdas");
		}

	public:
		void OnRosMsg(const std_msgs::Float32ConstPtr &_msg)
		{
			//	this->SetVelocity(_msg->data);
			ROS_INFO("Hello World");
		}

		/// \brief ROS helper function that processes messages
	private:
		void QueueThread()
		{
			static const double timeout = 0.01;
			while (this->rosNode->ok())
			{
				this->rosQueue.callAvailable(ros::WallDuration(timeout));
			}
		}
		// Called by the world update start event
	public:
		void OnUpdate()
		{
			float angleDegree = -90;
			float rad = M_PI * angleDegree / 180;

			std::string name = this->model->GetJoint("arm1_arm2_joint")->GetScopedName();
			std::string name1 = this->model->GetJoint("arm2_arm3_joint")->GetScopedName();

			std::string name2 = this->model->GetJoint("arm3_arm4_joint")->GetScopedName();
			std::string name0 = this->model->GetJoint("chasis_arm1_joint")->GetScopedName();

			// this->jointController->SetPositionPID(name, pid);
			// this->jointController->SetPositionTarget(name, rad);
			// this->jointController->Update();
			this->pid = common::PID(90.0, 00.00, 00.03);
			this->jointController->SetPositionTarget(name2, rad);
			// Get joint position by index.
			// 0 returns rotation accross X axis
			// 1 returns rotation accross Y axis
			// 2 returns rotation accross Z axis
			// If the Joint has only Z axis for rotation, 0 returns that value and 1 and 2 return nan
			double a1 = physics::JointState(this->model->GetJoint("arm1_arm2_joint")).Position(0);
			double a2 = physics::JointState(this->model->GetJoint("arm2_arm3_joint")).Position(0);
			double a3 = physics::JointState(this->model->GetJoint("arm3_arm4_joint")).Position(0);
			double a0 = physics::JointState(this->model->GetJoint("chasis_arm1_joint")).Position(0);
			// double a2 = this->model->GetJoint("chasis_arm1_joint").Position(0);
			// double a3 = physics::JointState(this->model->GetJoint("chasis_arm1_joint")).Position(2);
			// 	std::cout << "Current arm1_arm2_joint values: " << a1 * 180.0 / M_PI << std::endl;
			// 	std::cout << "Current arm2_arm3_joint values: " << a2 * 180.0 / M_PI << std::endl;
			// 	std::cout << "Current arm3_arm4_joint values: " << a3 * 180.0 / M_PI << std::endl;
			// 	std::cout << "Current chasis_arm1_joint values: " << a0 * 180.0 / M_PI << std::endl;
			//0
		}

		// a pointer that points to a model object
	private:
		physics::ModelPtr model;

		// 	// A joint controller object
		// 	// Takes PID value and apply angular velocity
		// 	//  or sets position of the angles
	private:
		physics::JointControllerPtr jointController;

	private:
		event::ConnectionPtr updateConnection;

		// // 	// PID object
	private:
		common::PID pid;

	private:
		std::unique_ptr<ros::NodeHandle> rosNode;

		/// \brief A ROS subscriber
	private:
		ros::Subscriber rosSub;

	private:
		ros::Publisher rosPub;
		/// \brief A ROS callbackqueue that helps process messages
	private:
		ros::CallbackQueue rosQueue;

		/// \brief A thread the keeps running the rosQueue
	private:
		std::thread rosQueueThread;

	private:
		ros::Timer timer;
	};

	// Register this plugin with the simulator
	GZ_REGISTER_MODEL_PLUGIN(ModelPush)
}